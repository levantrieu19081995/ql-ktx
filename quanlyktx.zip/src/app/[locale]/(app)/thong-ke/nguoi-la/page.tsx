import ClientPage from "../ClientPage";

export default function Page() {
  return <ClientPage type="nguoi-la" />;
}
