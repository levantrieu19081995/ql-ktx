"use client";

import React, { useEffect, useMemo, useState } from "react";
import {
  Badge,
  Button,
  Group,
  SimpleGrid,
  Stack,
  ThemeIcon,
  Title,
} from "@mantine/core";
import { IconSettings } from "@tabler/icons-react";
import { useTranslations } from "next-intl";
// import { INFOR_THANHTOAN, GIA_THUPHI } from "@/constants/dataMagic";

import SettingSystemInfo from "./SettingSystemInfo";
import SettingPreview from "./SettingPreview";
import SettingPaymentInfo from "./SettingPaymentInfo";
import SettingFeeInfo from "./SettingFeeInfo";
import SettingExcelViewer from "./SettingExcelViewer";
import { useRouter } from "next/navigation";
type CompanySettings = {
  title: string;
  primaryColor: string;
  address: string;
  phone: string;
  email: string;
  description: string;
  logoDataUrl?: string | null; // <= logo (base64) lưu localStorage
};

const STORAGE_KEY = "company_settings_v1";

const DEFAULT_SETTINGS: CompanySettings = {
  title: "QUẢN LÝ KÝ TÚC XÁ",
  primaryColor: "#4C6EF5",
  address: "Khu II, Đường 3/2, Xuân Khánh, Ninh Kiều, Cần Thơ",
  phone: "+84 292 3832 663",
  email: "dhct@ctu.edu.vn",
  description:
    "Hệ thống quản lý Ký túc xá Đại học Cần Thơ. Vận hành thông minh và theo dõi sinh viên vào ra.",
  logoDataUrl: null,
};
// type GiaThuPhi = typeof GIA_THUPHI;

export default function SettingPage() {
  const router = useRouter();
  const t = useTranslations("Settings");
  const [values, setValues] = useState<CompanySettings>(DEFAULT_SETTINGS);
  const [saved, setSaved] = useState(false);

  // const [paymentInfo, setPaymentInfo] = useState(INFOR_THANHTOAN);

  // const [feeValues, setFeeValues] = useState<GiaThuPhi>(GIA_THUPHI);

  const previewColor = useMemo(
    () => values.primaryColor || "#4C6EF5",
    [values.primaryColor],
  );

  // load từ localStorage
  useEffect(() => {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      try {
        const parsed = JSON.parse(raw) as CompanySettings;
        setValues({ ...DEFAULT_SETTINGS, ...parsed });
      } catch {
        /* ignore */
      }
    }
  }, []);

  return (
    <Stack gap="xl">
      {/* Header */}
      <Group justify="space-between">
        <Group>
          <ThemeIcon size={38} variant="light" color="indigo">
            <IconSettings size={20} />
          </ThemeIcon>
          <Title order={3}>{t("title")}</Title>
        </Group>
        <Group gap="xs">
          {saved && <Badge color="teal">Đã lưu... thay đổi hệ thống</Badge>}
        </Group>
      </Group>

      {/* Cầu hình thông tin hệ thông  */}
      <SimpleGrid cols={{ base: 1, md: 2 }} spacing="lg">
        <SettingSystemInfo
          values={values}
          onChange={(key, val) => setValues((s) => ({ ...s, [key]: val }))}
          setSaved={setSaved}
        />
        <SettingPreview values={values} previewColor={previewColor} />
      </SimpleGrid>
    </Stack>
  );
}
