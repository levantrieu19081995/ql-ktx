export const enums = {};
