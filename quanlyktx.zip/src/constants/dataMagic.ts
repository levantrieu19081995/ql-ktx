export const STATUS_CHU_SO_HUU = {
  ACTIVE: 'ACTIVE',
  INACTIVE: 'INACTIVE',
};
